import numpy as np

class Clustering():
    def __init__(self, k:int, initial_centroids:np.array, points:np.array):
        if k == len(initial_centroids):
            self.k = k
            self.initial_centroids = initial_centroids
            self.points = points
        
        else:
            raise ValueError('Number of initial centroids must match k')
            
    # Function to calculate Euclidean distance between two points
    def euclidean_distance(self, point1, point2):
        return np.sqrt(np.sum((point1 - point2) ** 2))

    # Function to perform K-means clustering
    def k_means(self, iterations):
        centroid_updated = self.initial_centroids
        if iterations == 0:
            clusters = [[] for j in range(len(centroid_updated))]
            for point in self.points:
                distance = []
                for centroid in centroid_updated:
                    dist = self.euclidean_distance(point, centroid)
                    distance.append(dist)
                closest_centroid_index = np.argmin(distance)
                clusters[closest_centroid_index].append(point)
            return clusters, centroid_updated
        
        else :
            for i in range(iterations):
                # Assignment step
                clusters = [[] for j in range(len(centroid_updated))]
                for point in self.points:
                    distance = []
                    for centroid in centroid_updated:
                        dist = self.euclidean_distance(point, centroid)
                        distance.append(dist)
                    closest_centroid_index = np.argmin(distance)
                    clusters[closest_centroid_index].append(point)
                
                # Update step
                for i in range(len(self.initial_centroids)):
                    if clusters[i]:
                        centroid_mean = np.mean(clusters[i], axis=0)
                        centroid_updated[i] = centroid_mean
            
            return clusters, centroid_updated
        
    def calculate_wcss(self, data, k):
        indices = np.random.choice(range(len(data)), size=k, replace=False)
        centroid_init = data[indices]
        
        clusters = [[] for _ in range(len(centroid_init))]
        for point in data:
            distances = [self.euclidean_distance(point, centroid) for centroid in centroid_init]
            closest_centroid_index = np.argmin(distances)
            clusters[closest_centroid_index].append(point)
            
        wcss = 0
        for i in range(len(centroid_init)):
            centroid = centroid_init[i]
            cluster = clusters[i]
            for point in cluster:
                wcss += self.euclidean_distance(point, centroid) ** 2
            
        return wcss

    def elbow_method(self, k_values:int):
        wcss_values = []
        for k in range(k_values):
            wcss = self.calculate_wcss(self.points, k+1)
            if k == 0:
                wcss_first = wcss
            wcss = wcss/wcss_first * 100
            if wcss > 10:
                k_select = k+2
            wcss_values.append(wcss)
        return wcss_values,k_select

class LogisticRegression:
    def __init__(self, learning_rate=0.01, num_iterations=1000):
        self.learning_rate = learning_rate
        self.num_iterations = num_iterations
        self.weights = None
        self.bias = None
        self.cost_history = []  # Store the cost history during training
    
    def sigmoid(self, z):
        return 1 / (1 + np.exp(-z))
    
    def compute_cost(self, y, y_predicted):
        # Binary Cross-Entropy Loss
        epsilon = 1e-15  # Small value to prevent log(0)
        cost = - np.mean(y * np.log(y_predicted + epsilon) + (1 - y) * np.log(1 - y_predicted + epsilon))
        return cost
    
    def fit(self, X, y):
        num_samples, num_features = X.shape
        self.weights = np.zeros((num_features, 1))  # Initialize as a column vector
        self.bias = 0

        # Gradient Descent
        for _ in range(self.num_iterations):
            # Linear combination
            linear_model = np.dot(X, self.weights) + self.bias
            # Sigmoid function
            y_predicted = self.sigmoid(linear_model)

            # Compute gradients
            dw = (1 / num_samples) * np.dot(X.T, (y_predicted - y))
            db = (1 / num_samples) * np.sum(y_predicted - y)

            # Update parameters
            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db

            # Compute and store the cost
            cost = self.compute_cost(y, y_predicted)
            self.cost_history.append(cost)
        
    def predict_prob(self, X):
        linear_model = np.dot(X, self.weights) + self.bias
        return self.sigmoid(linear_model)
    
    def predict(self, X, threshold=0.5):
        # Predict probabilities
        list_prob = []
        list_predict = []
        probabilities = self.predict_prob(X)
        list_prob.append(probabilities)
        # Threshold probabilities to obtain binary predictions
        for prob in probabilities:
            if prob >= threshold:
                predictions = 1
                list_predict.append(predictions)
            else:
                predictions = 0
                list_predict.append(predictions)
        return predictions,list_predict,list_prob

class Accuracy():
    def __init__(self, true, pred):
        self.true = true
        self.pred = pred
    
    def accuracy(self):
        correct = sum(1 for t, p in zip(self.true, self.pred) if t == p)
        total = len(self.true)
        accuracy = correct / total
        return accuracy

    def precision(self):
        true_positive = sum(1 for t, p in zip(self.true, self.pred) if t == 1 and p == 1)
        predicted_positive = sum(1 for p in self.pred if p == 1)
        if predicted_positive == 0:
            return 0
        precision = true_positive / predicted_positive
        return precision

    def recall(self):
        true_positive = sum(1 for t, p in zip(self.true, self.pred) if t == 1 and p == 1)
        actual_positive = sum(1 for t in self.true if t == 1)
        if actual_positive == 0:
            return 0
        recall = true_positive / actual_positive
        return recall

    def f1_score(self):
        prec = self.precision()
        rec = self.recall()
        # Compute F1 score
        if prec + rec == 0:
            return 0
        f1_score = 2 * (prec * rec) / (prec + rec)
        return f1_score
    

# Example usage
X_train = np.array([[1, 2], [2, 3], [3, 4], [4, 5]])
y_train = np.array([[0], [0], [1], [1]])  # Note the shape change to (n_samples, 1)

# Instantiate and train the model
model = LogisticRegression(0.015,10000)
model.fit(X_train, y_train)

# Plot the cost function
import matplotlib.pyplot as plt

plt.plot(range(1, model.num_iterations + 1), model.cost_history)
plt.xlabel('Iterations')
plt.ylabel('Cost')
plt.title('Cost Function')
plt.show()


train_predictions,list_predict,list_prob = model.predict(X_train)

Accuracy_model = Accuracy(y_train, list_predict)

print("Accuracy :", Accuracy_model.accuracy())
print("Precision :", Accuracy_model.precision())
print("Recall :", Accuracy_model.recall())
print("f1_score :", Accuracy_model.f1_score())
